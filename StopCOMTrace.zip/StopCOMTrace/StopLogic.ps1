<#
   Script will get trigger on specific event
   Check the message in the event and if it matches the expected event
   it will stop the traces.

#>

#Global Variables
$XmlPath = "C:\StopCOMTrace\Application_Windows Error Reporting_1001.xml"
$TaskPath = "\Event Viewer Tasks\"
$TaskName = "CTAC1001" 
$XperfPath = "c:\Xperf"
$LogDrive = "C:\"
$LogDir = "MSComTraces"
$Logs = $LogDrive + $LogDir
$EventLogFile = "EventLogs.log"
$User = "desktop-bvptiis\administrator"
$Pwd = "######"
$Tracker = "Tracker.log"

if (-Not(Test-Path -Path $Logs)) {
    New-item -Path $LogDrive -Name $LogDir -ItemType Directory
}

$GetEventLogs = {

    $timeStamp = get-date -Format "MM_dd_yyyy_HH_mm"
    
    $systemLogPath = $timeStamp + "_System.evtx"
    $systemLogPath = $Logs + "\" + $systemLogPath
    
    $applicationLogPath = $timeStamp + "_Application.evtx"
    $applicationLogPath = $Logs + "\" + $applicationLogPath
      
    wevtutil.exe epl System $systemLogPath
    wevtutil.exe epl Application $applicationLogPath

    #get-winevent -path  $applicationLogPath -MaxEvents 10 | out-file -FilePath $Logs"\"$EventLogFile -append
  
    
}


$StopComTrace = {

    $LogDrive = "C:\"
    $LogDir = "MSComTraces"
    $Logs = $LogDrive + $LogDir
    "Stop COM Trace.."
    logman stop "com_complus" -ets
}


$StopXperf = {

    $LogDrive = "C:\"
    $LogDir = "MSComTraces"
    $Logs = $LogDrive + $LogDir
    set-location -Path $XperfPath
    .\xperf -d $Logs"\Xperf_Wait.etl"
}


$Debug = 0

#Filter
$EventLogName = "Application"
$EventLevel = "4"
$EventId = "1001"
$EventEntryType = "Information"
$EventProviderName = "Windows Error Reporting"
$MessageToMonitor = "The CTACServer Service service terminated unexpectedly"

$FinalEventFilter = @{

    LogName      = $EventLogName
    ProviderName = $EventProviderName
    Level        = $EventLevel
    ID           = $EventId
    StartTime    = (get-date).AddMinutes(-2) 
}
$DummyEvent = {

    Write-EventLog -logname $EventLogName -source $EventProviderName -EntryType $EventEntryType -EventID $EventId -Message "The CTACServer Service service terminated unexpectedly" 
}

 
if ($Debug -eq 1) {
    .$DummyEvent
    $ErrorMessage = Get-WinEvent -FilterHashtable $FinalEventFilter -MaxEvents 1 -ErrorAction SilentlyContinue
    Write-host "$($ErrorMessage.Message)"
}


$CreateScheduledTask = {

    $taskInfo = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not($taskInfo.TaskName -eq $TaskName)) {
        Register-ScheduledTask -Taskpath $TaskPath -Xml (get-content -Path $XmlPath | out-string) -TaskName $TaskName -User $User -Password $Pwd -Force
    }

    
}

function  Collect-Trace {


    .$CreateScheduledTask
    if (-not(test-path -Path $XperfPath)) {
        write-output "xperf not found" | out-file -FilePath $Logs"\Xperf not found.log"
        return

    }

    $ErrorMessage = Get-WinEvent -FilterHashtable $FinalEventFilter -MaxEvents 1 -ErrorAction SilentlyContinue
    [string]$message = $($ErrorMessage.Message) | Out-String
    $message

    
    $TriggerCount += 1
    Write-Output  $(get-date) | Out-File -FilePath $Logs"\"$Tracker -Append

    if ($message.Contains($MessageToMonitor)) {
        .$StopXperf
        .$StopComTrace
        .$GetEventLogs

        $logDirName = get-date -Format "MM_dd_yyyy_HH_mm"
        $nameHost = HOSTNAME
        $logDirName = $logDirName + "_" + $nameHost
        New-Item -Name $logDirName -ItemType dir -Path $Logs"\"
        
        $ErrorMessage = Get-WinEvent -FilterHashtable $FinalEventFilter -MaxEvents 1 -ErrorAction SilentlyContinue
        Write-Output $($ErrorMessage.Message) | Out-File -FilePath $Logs"\"$EventLogFile

        set-location -Path $Logs
        Move-Item -Path $Logs"\*.*" -Destination $Logs"\"$logDirName 

    }

}

Collect-Trace