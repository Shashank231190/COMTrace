$XperfPath = "c:\Xperf"
$LogDrive = "C:\"
$LogDir = "MSComTraces"
$Logs = $LogDrive + $LogDir
$EventLogFile = "EventLogs.log"

if (-Not(Test-Path -Path $Logs)) {
    New-item -Path $LogDrive -Name $LogDir -ItemType Directory
}


$StartComTrace = {

    "Enabling COM Trace.."

    reg add HKEY_LOCAL_MACHINE\Software\Microsoft\OLE\Tracing /v ExecutablesToTrace /t REG_MULTI_SZ /d * /f
    logman create trace "com_complus" -ow -o $Logs"\com_complus.etl" -p `{A0C4702B-51F7-4EA9-9C74-E39952C694B8`} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
    logman update trace "com_complus" -p `{53201895-60E8-4FB0-9643-3F80762D658F`} 0xffffffffffffffff 0xff -ets
    logman update trace "com_complus" -p `{B46FA1AD-B22D-4362-B072-9F5BA07B046D`} 0xffffffffffffffff 0xff -ets
    logman update trace "com_complus" -p `{9474A749-A98D-4F52-9F45-5B20247E4F01`} 0xffffffffffffffff 0xff -ets
    logman update trace "com_complus" -p `{BDA92AE8-9F11-4D49-BA1D-A4C2ABCA692E`} 0xffffffffffffffff 0xff -ets

}

$StartXperfTrace = {

    "Xperf Trace.."
    $timeStamp = get-date -Format HH_mm_ss
    $XperfKernelETL = "Start_Xperf" + $timeStamp + "_kernel.etl"
    $XperfDir = $Logs + "\" + $XperfKernelETL
    Set-Location -Path $XperfPath
    .\xperf -on PROC_THREAD+LOADER+FLT_IO_INIT+FLT_IO+FLT_FASTIO+FLT_IO_FAILURE+FILENAME+FILE_IO+FILE_IO_INIT+DISK_IO+HARD_FAULTS+DPC+INTERRUPT+CSWITCH+PROFILE+DRIVERS+Latency+DISPATCHER -stackwalk MiniFilterPreOpInit+MiniFilterPostOpInit+CSwitch+ReadyThread+ThreadCreate+Profile+DiskReadInit+DiskWriteInit+DiskFlushInit+FileCreate+FileCleanup+FileClose+FileRead+FileWrite+FileFlush -BufferSize 4096 -MaxBuffers 4096 -MaxFile 4096 -FileMode Circular -f $XperfDir 

}

function Start-Trace {

    $AssertLogPath = Get-ChildItem $LogPath -ErrorAction Stop
    $AssertXperfLocation = Get-ChildItem $XperfLocation -ErrorAction Stop
    "Starting Trace"
    .$StartXperfTrace
    .$StartComTrace


    
}

Start-Trace