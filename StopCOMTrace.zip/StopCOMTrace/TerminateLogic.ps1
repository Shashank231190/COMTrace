$XperfPath = "c:\Xperf"
$LogDrive = "C:\"
$LogDir = "MSComTraces"
$Logs = $LogDrive + $LogDir
$TerminateLogFile = "Terminate.log"


$StopComTrace = {

    $LogDrive = "C:\"
    $LogDir = "MSComTraces"
    $Logs = $LogDrive + $LogDir
    "Stop COM Trace.."
    logman stop "com_complus" -ets
}


$StopXperf = {

    $LogDrive = "C:\"
    $LogDir = "MSComTraces"
    $Logs = $LogDrive + $LogDir
    set-location -Path $XperfPath
    .\xperf -d $Logs"\Xperf_Wait.etl"
}


function  Terminate {

    $Que = read-host "You want to stop the traces forcefully[y/n]"
    if ($Que -eq 'y') {

        .$StopXperf
        .$StopComTrace
     

        $logDirName = get-date -Format "MM_dd_yyyy_HH_mm"
        $nameHost = HOSTNAME
        $logDirName = $logDirName + "_" + $nameHost
        New-Item -Name $logDirName -ItemType dir -Path $Logs"\"
        
        Write-Output $(get-date) | Out-File -FilePath $Logs"\"$TerminateLogFile

        set-location -Path $Logs
        Move-Item -Path $Logs"\*.*" -Destination $Logs"\"$logDirName 
        
    }

    
  
 
}

Terminate
